package net.serenitybdd.core.di;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.ContextHierarchy;
import org.springframework.test.context.TestContextManager;

public class SpringDependencyInjector implements DependencyInjector {

	private static final Map<Object, TestContextManager> contextManagerMap = new HashMap<>();

	/**
	 * Setup Spring dependencies in a step library, based on the Spring ContextConfiguration annotation.
	 * 
	 * @param target
	 */
	@Override
	public void injectDependenciesInto(Object target) {
		if (springIsOnClasspath() && annotatedWithSpringContext(target)) {
			TestContextManager contextManager = getTestContextManager(target.getClass());
			contextManagerMap.put(target, contextManager);
			try {
				contextManager.prepareTestInstance(target);
			} catch (Exception e) {
				throw new IllegalStateException("Could not instantiate test instance", e);
			}
		}
	}

	@Override
	public void reset() {
	}

	private boolean annotatedWithSpringContext(Object target) {

		return (AnnotationUtils.findAnnotation(target.getClass(), ContextConfiguration.class) != null) || (AnnotationUtils.findAnnotation(target.getClass(), ContextHierarchy.class) != null);
	}

	private boolean springIsOnClasspath() {
		try {
			Class.forName("org.springframework.test.context.ContextConfiguration");
			return true;
		} catch (ClassNotFoundException e) {
			return false;
		}
	}

	protected TestContextManager getTestContextManager(Class<?> clazz) {

		return new TestContextManager(clazz);
	}

	public static TestContextManager getTextContextManager(Object target) {
		return contextManagerMap.get(target);
	}
}
