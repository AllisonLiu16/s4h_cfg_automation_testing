package com.sap.set.packman;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.naming.NamingException;
import org.apache.derby.jdbc.EmbeddedDataSource;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mock.jndi.SimpleNamingContextBuilder;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import net.thucydides.core.webdriver.ThucydidesWebDriverSupport;
import net.thucydides.core.webdriver.WebDriverFacade;

@Configuration
public class TXEBeanProvider {

    @Bean
    @JobScope
    public RemoteWebDriver getWebDriver() {
        WebDriverFacade driver = (WebDriverFacade)ThucydidesWebDriverSupport.getWebdriverManager().getCurrentDriver();
        return (RemoteWebDriver)driver.getProxiedDriver();
        // return this.getDriver.asInstanceOf[RemoteWebDriver]
    }

    @Bean
    @JobScope
    public WebDriverWait getWebDriverWait(RemoteWebDriver driver) {
        return new WebDriverWait(driver, 300);
    }

    @PostConstruct
    public void init() throws IllegalStateException, NamingException {
        SimpleNamingContextBuilder builder = new SimpleNamingContextBuilder();
        EmbeddedDataSource dataSource = new EmbeddedDataSource();
        dataSource.setDatabaseName("memory:TestDB");
        dataSource.setCreateDatabase("create");
        builder.bind("java:comp/env/jdbc/TXEDB", dataSource);
        builder.activate();
    }

    @Bean
    public RetryTemplate retryTemplate() {
        Map<Class<? extends Throwable>, Boolean> exceptionMap = new HashMap<>();
        exceptionMap.put(java.lang.Exception.class, true);
        exceptionMap.put(java.lang.RuntimeException.class, true);

        SimpleRetryPolicy retryPolicy = new SimpleRetryPolicy(3, exceptionMap);

        FixedBackOffPolicy backOffPolicy = new FixedBackOffPolicy();
        backOffPolicy.setBackOffPeriod(3000); // 1.5 seconds

        RetryTemplate template = new RetryTemplate();
        template.setRetryPolicy(retryPolicy);
        template.setBackOffPolicy(backOffPolicy);
        return template;
    }
}
