package com.sap.set.packman;

import net.serenitybdd.jbehave.SerenityStories;

public class TestSuite extends SerenityStories{

}
