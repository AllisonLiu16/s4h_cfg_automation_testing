package com.sap.set.packman;

import javax.annotation.Resource;
import org.jbehave.core.annotations.AfterScenario;
import org.jbehave.core.annotations.BeforeScenario;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.scope.context.StepSynchronizationManager;
import org.springframework.batch.test.JobScopeTestExecutionListener;
import org.springframework.batch.test.StepScopeTestExecutionListener;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestContextManager;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import com.sap.sakp.fiori.actionkeyword.CheckBox;
import com.sap.sakp.fiori.actionkeyword.Click;
import com.sap.sakp.fiori.actionkeyword.DropdownList;
import com.sap.sakp.fiori.actionkeyword.Input;
import com.sap.sakp.fiori.actionkeyword.Press;
import com.sap.sakp.fiori.actionkeyword.SelectRow;
import com.sap.sakp.fiori.assertkeyword.AssertDisplayed;
import com.sap.sakp.fiori.assertkeyword.Define;
import com.sap.sakp.fiori.assertkeyword.GetValue;
import com.sap.sakp.fiori.locatorkeyword.InRow;
import com.sap.sakp.fiori.locatorkeyword.InSection;
import com.sap.sakp.keyword.entity.KeywordParameter;
import net.serenitybdd.core.di.SpringDependencyInjector;
import net.serenitybdd.junit.spring.integration.SpringIntegrationSerenityRunner;
import net.thucydides.core.annotations.Managed;

@RunWith(SpringIntegrationSerenityRunner.class)
@ContextConfiguration({"classpath*:applicationContext.xml", "classpath*:applicationContext-fiori.xml"})
@TestExecutionListeners({DependencyInjectionTestExecutionListener.class, StepScopeTestExecutionListener.class, JobScopeTestExecutionListener.class})
public class FioriKeywordLibraryWrapper {

    @Autowired
    ApplicationContext applicationContext;

    @Autowired
    Click click;

    @Autowired
    Input input;

    @Autowired
    @Qualifier("check")
    CheckBox check;

    @Autowired
    @Qualifier("uncheck")
    CheckBox uncheck;

    @Autowired
    @Qualifier("select")
    DropdownList combobox;

    @Autowired
    Press press;

    @Autowired
    Define define;

    @Autowired
    @Qualifier("select row")
    SelectRow selectRow;

    @Resource(name = "in row")
    InRow inRow;

    @Autowired
    InSection inSection;

    @Autowired
    AssertDisplayed assertDisplayed;

    @Autowired
    GetValue getValue;
    
    @Autowired
    RetryTemplate retryTemplate;

    @Managed
    WebDriver driver;

    public void assertKeywordResult() {
        Assert.assertNotEquals(ExitStatus.FAILED, StepSynchronizationManager.getContext().getStepExecution().getExitStatus());
    }

    @BeforeScenario
    public void before() throws Exception {
    	TestContextManager testContextManager = SpringDependencyInjector.getTextContextManager(this);
        testContextManager.beforeTestMethod(this, null);
        try {
            applicationContext.getBean(driver.getClass());
        } catch (NoSuchBeanDefinitionException e){
        	ConfigurableListableBeanFactory beanFactory = ((ConfigurableApplicationContext) applicationContext).getBeanFactory();
                beanFactory.registerSingleton(driver.getClass().getCanonicalName(), driver);
        }
    }

    @AfterScenario
    public void after() throws Exception {
    	TestContextManager testContextManager = SpringDependencyInjector.getTextContextManager(this);
        testContextManager.afterTestMethod(this, null, null);
    }
    
    /**
     * by clockrun
     * attention: we must use relative URL here
     */
    @Given("url $url")
    public void open(String url) {
        driver.manage().window().maximize();
        driver.get(url);
    }

    @When("login with user: $username and password: $password")
    public void login(String username, String password) {

    }

    @Then("$text should displayed")
    public void shoudDisplayed(String text) {
    }

    @When("click $textOrIcon")
    public void executeClick(String field) throws Exception {
        KeywordParameter parameter = new KeywordParameter();
        parameter.setField(field);
        retryTemplate.execute(context -> click.process(parameter));
        assertKeywordResult();
    }

    @When("input $field with $value")
    public void executeInput(String field, String value) throws Exception {
        KeywordParameter parameter = new KeywordParameter();
        parameter.setField(field);
        parameter.setValue(value);
        retryTemplate.execute(context -> input.process(parameter));
        assertKeywordResult();
    }

    @When("check $field")
    public void executeCheck(String field) throws Exception {
        KeywordParameter parameter = new KeywordParameter();
        parameter.setField(field);
        retryTemplate.execute(context -> check.process(parameter));
        assertKeywordResult();
    }

    @When("uncheck $field")
    public void executeUnCheck(String field) throws Exception {
        KeywordParameter parameter = new KeywordParameter();
        parameter.setField(field);
        retryTemplate.execute(context -> uncheck.process(parameter));
        assertKeywordResult();
    }

    @When("select $field with $value")
    public void executeSelect(String field, String value) throws Exception {
        KeywordParameter parameter = new KeywordParameter();
        parameter.setField(field);
        parameter.setValue(value);
        retryTemplate.execute(context -> combobox.process(parameter));
        assertKeywordResult();
    }

    @When("press $field with key $value")
    public void executePress(String field, String value) throws Exception {
        KeywordParameter parameter = new KeywordParameter();
        parameter.setField(field);
        parameter.setValue(value);
        retryTemplate.execute(context -> press.process(parameter));
        assertKeywordResult();
    }

    @When("select row $field")
    public void executeSelectRow(String field) throws Exception {
        KeywordParameter parameter = new KeywordParameter();
        parameter.setField(field);
        retryTemplate.execute(context -> selectRow.process(parameter));
        assertKeywordResult();
    }

    @Given("row $text")
    public void executeInRow(String text) throws Exception {
        KeywordParameter parameter = new KeywordParameter();
        parameter.setField(text);
        retryTemplate.execute(context -> inRow.process(parameter));
        assertKeywordResult();
    }

    @Given("section $field")
    public void executeInSection(String field) throws Exception {
        KeywordParameter parameter = new KeywordParameter();
        parameter.setField(field);
        retryTemplate.execute(context -> inSection.process(parameter));
        assertKeywordResult();
    }

    @Then("should see $text")
    public void executeAssertDisplayed(String text) throws Exception {
        KeywordParameter parameter = new KeywordParameter();
        parameter.setField(text);
        retryTemplate.execute(context -> assertDisplayed.process(parameter));
        assertKeywordResult();
    }

    // TODO research if we still need it
    public void executeGetValue(String field, String value) throws Exception {
        KeywordParameter parameter = new KeywordParameter();
        parameter.setField(field);
        parameter.setValue(value);
        getValue.process(parameter);
        assertKeywordResult();
    }

    @Given("$name=$value")
    public void executeDefine(String name, String value) throws Exception {
        KeywordParameter parameter = new KeywordParameter();
        parameter.setField(name);
        parameter.setValue(value);
        define.process(parameter);
        assertKeywordResult();
    }
}
